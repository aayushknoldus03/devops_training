num1 = "8"
num2= "7"
first_number = int(input("enter number"))
second_number = int(input("enter number"))
output = first_number +second_number
sum = num1 + num2
print("sum is",output)
print(sum)
diff = first_number - second_number
product = first_number * second_number
rem = first_number / second_number
print("diff is",diff)
print("product is",product)
print("remainder is",rem)