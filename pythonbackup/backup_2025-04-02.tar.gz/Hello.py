print("hello")
name = "aayush"
sirname = input("enter sirname: ")
print("hello",name,sirname)