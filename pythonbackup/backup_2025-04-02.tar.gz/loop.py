list_of_cloud = ["aws","azure","gcp","digital ocean"]
print(list_of_cloud)

list_of_cloud.append("sales force")
print(list_of_cloud)
list_of_cloud.insert(2,"IBM")
print(list_of_cloud)
print(len(list_of_cloud))

for cloud in list_of_cloud:
    print(cloud)

for i in range(1,11): #exclude last element
    print(i)


